import numpy as np
import pandas as pd
from Stroke import Stroke
from mobile import Mobile
from models import Model
from livefacebook import Live
from insurance import Ins
from tkinter import ttk, Tk
import tkinter as tk
from PIL import ImageTk, Image

root = Tk()
root.title('Machine Learning Models')
#root.iconbitmap('c:/gui/codemy.ico')
root.geometry("800x500")  

model = Model()

mob = Mobile()
mob_data = mob.load()

stro = Stroke()
str_data = stro.load()

liv = Live()
liv_data = liv.load()

ins = Ins()
ins_data = ins.load()


ttk.Label(root, "")


n = tk.StringVar()
data_choosen = ttk.Combobox(root, width = 27, textvariable = n)
data_choosen['values'] = (
    ' Live Facebook Data', 
    ' Mobile Data', 
    ' Stroke Data',
    ' Health Insurance Data'
)



root.mainloop()



import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt

class Mobile:
    def __init__(self):
        self.data = pd.read_csv("train_mobile.csv")
        y = self.data['price_range']
        self.data.drop(['price_range'], axis=1, inplace=True)
        self.data['y'] = y

    def ret_data(self):
        return self.data.head()

    def desc(self):
        return self.data.describe()

    def plot1(self):
        sns.jointplot(x='ram', y='price_range', data=self.data, color='red', kind='kde')
        plt.show()
        return

    def plot2(self):
        labels = ["3G-supported", 'Not supported']
        values = self.data['three_g'].value_counts().values
        fig1, ax1 = plt.subplots()
        ax1.pie(values, labels=labels, autopct='%1.1f%%', shadow=True, startangle=90)
        plt.show()
        return

    def plot3(self):
        labels4g = ["4G-supported", 'Not supported']
        values4g = self.data['four_g'].value_counts().values
        fig1, ax1 = plt.subplots()
        ax1.pie(values4g, labels=labels4g, autopct='%1.1f%%', shadow=True, startangle=90)
        plt.show()
        return

    def plot4(self):
        sns.boxplot(x="price_range", y="battery_power", data=self.data)
        plt.show()
        return
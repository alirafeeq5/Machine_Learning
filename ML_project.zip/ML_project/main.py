import numpy as np
import pandas as pd
from Stroke import Stroke
from mobile import Mobile
from models import Model
import math
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
model = Model()
objmo = Stroke()
print(model.naive(objmo.load()))
